package com.util;

public class ImgUpload {
  public static String IMG_PATH="/alidata/server/tomcat-7.0.54/webapps/YindaOA/upload/";
}
