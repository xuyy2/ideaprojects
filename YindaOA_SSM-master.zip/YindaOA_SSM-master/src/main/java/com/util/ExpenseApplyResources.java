package com.util;
/**
 * 各类路径存储
 * @author mawei
 *
 */
public class ExpenseApplyResources {
	//图片保存路径
 public static String IMG_SAVE_PATH="/alidata/server/tomcat-7.0.54/webapps/YindaOAImageUpload/";
// public  static String IMG_SAVE_PATH="E://YindaOAImageUpload/";
  //审批link链接URL
//  public static String approve_Message_URL_TRAIN="http://mawei.ngrok.cc/YindaOA/to_approve_train.do?id=";
//  public static String approve_Message_URL_BUS="http://mawei.ngrok.cc/YindaOA/to_approve_bus.do?id=";
//  public static String approve_Message_URL_HOTEL="http://mawei.ngrok.cc/YindaOA/to_approve_hotel.do?id=";
//  public static String approve_Message_URL_SUBWAY="http://mawei.ngrok.cc/YindaOA/toExpense_subway_approve.do?id=";
  public static String approve_Message_URL_TRAIN="http://121.40.29.241/YindaOA/to_approve_train.do?id=";
  public static String approve_Message_URL_BUS="http://121.40.29.241/YindaOA/to_approve_bus.do?id=";
  public static String approve_Message_URL_HOTEL="http://121.40.29.241/YindaOA/to_approve_hotel.do?id=";
  public static String approve_Message_URL_SUBWAY="http://121.40.29.241/YindaOA/toExpense_subway_approve.do?id=";
  //审批LINK链接图片URL
  public static String approve_Message_picUrl="http://121.40.29.241/YindaOA/images/approve.png";
//    public static String approve_Message_picUrl="http://mawei.ngrok.cc/YindaOA/images/approve.png";

}
