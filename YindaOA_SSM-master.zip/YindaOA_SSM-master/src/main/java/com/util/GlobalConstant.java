package com.util;

public class GlobalConstant {
    public static String user_department="user_department";
    public static String user_name="user_name";
    public static String user_staffId="staff_id";
    public static String user_staff_user_id="staff_user_id";
}
