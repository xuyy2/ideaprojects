package com.ecache;

import java.util.UUID;

public class SystemConfig {
 public  static String  version =UUID.randomUUID().toString();
}
