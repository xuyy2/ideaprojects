package com.model;

public class YoSignIn {
    private Integer siSequenceNo;

    private String siName;

    private String siStaffId;

    private String siDepartment;

    private String siCompleteDepartment;

    private String siJobPosition;

    private String siDate;

    private String siTime;

    private String siLongitude;

    private String siLatitude;

    private String siAddress;

    private String siCompleteAddress;

    private String siMeet;

    private String siComment;

    private String siCellphoneId;

    private String siImage1;

    private String siImage2;

    private String siImage3;

    private String siImage4;

    private String siImage5;

    private String siImage6;

    private String siImage7;

    private String siImage8;

    private String siImage9;

    public Integer getSiSequenceNo() {
        return siSequenceNo;
    }

    public void setSiSequenceNo(Integer siSequenceNo) {
        this.siSequenceNo = siSequenceNo;
    }

    public String getSiName() {
        return siName;
    }

    public void setSiName(String siName) {
        this.siName = siName;
    }

    public String getSiStaffId() {
        return siStaffId;
    }

    public void setSiStaffId(String siStaffId) {
        this.siStaffId = siStaffId;
    }

    public String getSiDepartment() {
        return siDepartment;
    }

    public void setSiDepartment(String siDepartment) {
        this.siDepartment = siDepartment;
    }

    public String getSiCompleteDepartment() {
        return siCompleteDepartment;
    }

    public void setSiCompleteDepartment(String siCompleteDepartment) {
        this.siCompleteDepartment = siCompleteDepartment;
    }

    public String getSiJobPosition() {
        return siJobPosition;
    }

    public void setSiJobPosition(String siJobPosition) {
        this.siJobPosition = siJobPosition;
    }

    public String getSiDate() {
        return siDate;
    }

    public void setSiDate(String siDate) {
        this.siDate = siDate;
    }

    public String getSiTime() {
        return siTime;
    }

    public void setSiTime(String siTime) {
        this.siTime = siTime;
    }

    public String getSiLongitude() {
        return siLongitude;
    }

    public void setSiLongitude(String siLongitude) {
        this.siLongitude = siLongitude;
    }

    public String getSiLatitude() {
        return siLatitude;
    }

    public void setSiLatitude(String siLatitude) {
        this.siLatitude = siLatitude;
    }

    public String getSiAddress() {
        return siAddress;
    }

    public void setSiAddress(String siAddress) {
        this.siAddress = siAddress;
    }

    public String getSiCompleteAddress() {
        return siCompleteAddress;
    }

    public void setSiCompleteAddress(String siCompleteAddress) {
        this.siCompleteAddress = siCompleteAddress;
    }

    public String getSiMeet() {
        return siMeet;
    }

    public void setSiMeet(String siMeet) {
        this.siMeet = siMeet;
    }

    public String getSiComment() {
        return siComment;
    }

    public void setSiComment(String siComment) {
        this.siComment = siComment;
    }

    public String getSiCellphoneId() {
        return siCellphoneId;
    }

    public void setSiCellphoneId(String siCellphoneId) {
        this.siCellphoneId = siCellphoneId;
    }

    public String getSiImage1() {
        return siImage1;
    }

    public void setSiImage1(String siImage1) {
        this.siImage1 = siImage1;
    }

    public String getSiImage2() {
        return siImage2;
    }

    public void setSiImage2(String siImage2) {
        this.siImage2 = siImage2;
    }

    public String getSiImage3() {
        return siImage3;
    }

    public void setSiImage3(String siImage3) {
        this.siImage3 = siImage3;
    }

    public String getSiImage4() {
        return siImage4;
    }

    public void setSiImage4(String siImage4) {
        this.siImage4 = siImage4;
    }

    public String getSiImage5() {
        return siImage5;
    }

    public void setSiImage5(String siImage5) {
        this.siImage5 = siImage5;
    }

    public String getSiImage6() {
        return siImage6;
    }

    public void setSiImage6(String siImage6) {
        this.siImage6 = siImage6;
    }

    public String getSiImage7() {
        return siImage7;
    }

    public void setSiImage7(String siImage7) {
        this.siImage7 = siImage7;
    }

    public String getSiImage8() {
        return siImage8;
    }

    public void setSiImage8(String siImage8) {
        this.siImage8 = siImage8;
    }

    public String getSiImage9() {
        return siImage9;
    }

    public void setSiImage9(String siImage9) {
        this.siImage9 = siImage9;
    }
}