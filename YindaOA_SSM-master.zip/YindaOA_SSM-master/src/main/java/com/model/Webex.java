package com.model;

public class Webex {
    private Integer id;

    private String meetingCount;

    private String meetingDesc;

    private String meetingLength;

    private String meetingName;

    private String meetingPassword;

    private String meetingTime;

    private String sessionKey;

    private Integer trainNowNumber;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getMeetingCount() {
        return meetingCount;
    }

    public void setMeetingCount(String meetingCount) {
        this.meetingCount = meetingCount;
    }

    public String getMeetingDesc() {
        return meetingDesc;
    }

    public void setMeetingDesc(String meetingDesc) {
        this.meetingDesc = meetingDesc;
    }

    public String getMeetingLength() {
        return meetingLength;
    }

    public void setMeetingLength(String meetingLength) {
        this.meetingLength = meetingLength;
    }

    public String getMeetingName() {
        return meetingName;
    }

    public void setMeetingName(String meetingName) {
        this.meetingName = meetingName;
    }

    public String getMeetingPassword() {
        return meetingPassword;
    }

    public void setMeetingPassword(String meetingPassword) {
        this.meetingPassword = meetingPassword;
    }

    public String getMeetingTime() {
        return meetingTime;
    }

    public void setMeetingTime(String meetingTime) {
        this.meetingTime = meetingTime;
    }

    public String getSessionKey() {
        return sessionKey;
    }

    public void setSessionKey(String sessionKey) {
        this.sessionKey = sessionKey;
    }

    public Integer getTrainNowNumber() {
        return trainNowNumber;
    }

    public void setTrainNowNumber(Integer trainNowNumber) {
        this.trainNowNumber = trainNowNumber;
    }
}