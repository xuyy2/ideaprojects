package com.model;

public class YoYindaIdentify {
    private Integer yiSequenceNo;

    private String yiApproveNo;

    private String yiTitle;

    private String yiApproveState;

    private String yiApproveResult;

    private String yiApproveBegin;

    private String yiApproveEnd;

    private String yiAskStaffId;

    private String yiAskStaffName;

    private String yiAskStaffDepart;

    private String yiHistoryApproveName;

    private String yiApproveRecord;

    private String yiNowApproveName;

    private String yiCost;

    private String yiYindaLevel;

    private String yiEffectDate;

    public Integer getYiSequenceNo() {
        return yiSequenceNo;
    }

    public void setYiSequenceNo(Integer yiSequenceNo) {
        this.yiSequenceNo = yiSequenceNo;
    }

    public String getYiApproveNo() {
        return yiApproveNo;
    }

    public void setYiApproveNo(String yiApproveNo) {
        this.yiApproveNo = yiApproveNo;
    }

    public String getYiTitle() {
        return yiTitle;
    }

    public void setYiTitle(String yiTitle) {
        this.yiTitle = yiTitle;
    }

    public String getYiApproveState() {
        return yiApproveState;
    }

    public void setYiApproveState(String yiApproveState) {
        this.yiApproveState = yiApproveState;
    }

    public String getYiApproveResult() {
        return yiApproveResult;
    }

    public void setYiApproveResult(String yiApproveResult) {
        this.yiApproveResult = yiApproveResult;
    }

    public String getYiApproveBegin() {
        return yiApproveBegin;
    }

    public void setYiApproveBegin(String yiApproveBegin) {
        this.yiApproveBegin = yiApproveBegin;
    }

    public String getYiApproveEnd() {
        return yiApproveEnd;
    }

    public void setYiApproveEnd(String yiApproveEnd) {
        this.yiApproveEnd = yiApproveEnd;
    }

    public String getYiAskStaffId() {
        return yiAskStaffId;
    }

    public void setYiAskStaffId(String yiAskStaffId) {
        this.yiAskStaffId = yiAskStaffId;
    }

    public String getYiAskStaffName() {
        return yiAskStaffName;
    }

    public void setYiAskStaffName(String yiAskStaffName) {
        this.yiAskStaffName = yiAskStaffName;
    }

    public String getYiAskStaffDepart() {
        return yiAskStaffDepart;
    }

    public void setYiAskStaffDepart(String yiAskStaffDepart) {
        this.yiAskStaffDepart = yiAskStaffDepart;
    }

    public String getYiHistoryApproveName() {
        return yiHistoryApproveName;
    }

    public void setYiHistoryApproveName(String yiHistoryApproveName) {
        this.yiHistoryApproveName = yiHistoryApproveName;
    }

    public String getYiApproveRecord() {
        return yiApproveRecord;
    }

    public void setYiApproveRecord(String yiApproveRecord) {
        this.yiApproveRecord = yiApproveRecord;
    }

    public String getYiNowApproveName() {
        return yiNowApproveName;
    }

    public void setYiNowApproveName(String yiNowApproveName) {
        this.yiNowApproveName = yiNowApproveName;
    }

    public String getYiCost() {
        return yiCost;
    }

    public void setYiCost(String yiCost) {
        this.yiCost = yiCost;
    }

    public String getYiYindaLevel() {
        return yiYindaLevel;
    }

    public void setYiYindaLevel(String yiYindaLevel) {
        this.yiYindaLevel = yiYindaLevel;
    }

    public String getYiEffectDate() {
        return yiEffectDate;
    }

    public void setYiEffectDate(String yiEffectDate) {
        this.yiEffectDate = yiEffectDate;
    }
}