package com.model;

public class YoAnnualVacation {
    private Integer avSequenceNo;

    private String avDingdingUserId;

    private String avName;

    private String avStaffId;

    private String avDepartment;

    private Integer avYear;

    private Float avLeftVecationDays;

    private String avLeftDaysoffDays;

    public Integer getAvSequenceNo() {
        return avSequenceNo;
    }

    public void setAvSequenceNo(Integer avSequenceNo) {
        this.avSequenceNo = avSequenceNo;
    }

    public String getAvDingdingUserId() {
        return avDingdingUserId;
    }

    public void setAvDingdingUserId(String avDingdingUserId) {
        this.avDingdingUserId = avDingdingUserId;
    }

    public String getAvName() {
        return avName;
    }

    public void setAvName(String avName) {
        this.avName = avName;
    }

    public String getAvStaffId() {
        return avStaffId;
    }

    public void setAvStaffId(String avStaffId) {
        this.avStaffId = avStaffId;
    }

    public String getAvDepartment() {
        return avDepartment;
    }

    public void setAvDepartment(String avDepartment) {
        this.avDepartment = avDepartment;
    }

    public Integer getAvYear() {
        return avYear;
    }

    public void setAvYear(Integer avYear) {
        this.avYear = avYear;
    }

    public Float getAvLeftVecationDays() {
        return avLeftVecationDays;
    }

    public void setAvLeftVecationDays(Float avLeftVecationDays) {
        this.avLeftVecationDays = avLeftVecationDays;
    }

    public String getAvLeftDaysoffDays() {
        return avLeftDaysoffDays;
    }

    public void setAvLeftDaysoffDays(String avLeftDaysoffDays) {
        this.avLeftDaysoffDays = avLeftDaysoffDays;
    }
}