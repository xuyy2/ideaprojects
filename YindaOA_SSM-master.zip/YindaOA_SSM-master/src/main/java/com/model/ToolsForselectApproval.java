package com.model;

public class ToolsForselectApproval {
	private String staffUserId;
	private String staffId;
	public String getStaffUserId() {
		return staffUserId;
	}
	public void setStaffUserId(String staffUserId) {
		this.staffUserId = staffUserId;
	}
	public String getStaffId() {
		return staffId;
	}
	public void setStaffId(String staffId) {
		this.staffId = staffId;
	}
	
}
