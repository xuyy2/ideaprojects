package com.model;

public class YoOrderProperty {
    private Integer id;

    private String orderName;

    private String orderNumber;

    private String orderProvince;

    private String orderCity;

    private String orderBusinessProperty;

    private String orderRemark;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getOrderName() {
        return orderName;
    }

    public void setOrderName(String orderName) {
        this.orderName = orderName;
    }

    public String getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }

    public String getOrderProvince() {
        return orderProvince;
    }

    public void setOrderProvince(String orderProvince) {
        this.orderProvince = orderProvince;
    }

    public String getOrderCity() {
        return orderCity;
    }

    public void setOrderCity(String orderCity) {
        this.orderCity = orderCity;
    }

    public String getOrderBusinessProperty() {
        return orderBusinessProperty;
    }

    public void setOrderBusinessProperty(String orderBusinessProperty) {
        this.orderBusinessProperty = orderBusinessProperty;
    }

    public String getOrderRemark() {
        return orderRemark;
    }

    public void setOrderRemark(String orderRemark) {
        this.orderRemark = orderRemark;
    }
}