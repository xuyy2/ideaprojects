package com.ddSdk.message;


public abstract class Message {
	public abstract String type();
}
