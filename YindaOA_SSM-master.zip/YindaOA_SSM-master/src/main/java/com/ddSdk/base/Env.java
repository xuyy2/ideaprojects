package com.ddSdk.base;



public class Env {
	
	public static final String OAPI_HOST = "https://oapi.dingtalk.com";
	public static final String OA_BACKGROUND_URL = ""; 
	public static final String CORP_ID = "ding246914ee44e47d4c";
	
	public static final String CORP_SECRET = "Vnm79JLaXD1oiiZi-XV4LJlVW6KOYJmvWQfr3Z5mr-fZA8HSkMMhcoAySyRB5D_8";
	public static final String SSO_Secret = "";

	public static String suiteTicket; 
	public static String authCode; 
	public static String suiteToken; 

	public static final String CREATE_SUITE_KEY = "suite4xxxxxxxxxxxxxxx";
	public static final String SUITE_KEY = "";
	public static final String SUITE_SECRET = "";
	public static final String TOKEN = "";
	public static final String ENCODING_AES_KEY = "";
	
}
