package com.ddSdk.base;

public class Vars {

	public static String TO_USER = "";
	public static String TO_PARTY = "";
	public static String AGENT_ID = "";
	public static String SENDER = "";
	public static String CID = "";//cid需要通过jsapi获取，具体详情请查看开放平台文档--->客户端文档--->会话
}
