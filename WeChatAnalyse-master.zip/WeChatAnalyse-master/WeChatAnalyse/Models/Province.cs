﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WeChatAnalyse.Models
{
    public class Province
    {
        public string name { get; set; }
        public int value { get; set; }
    }
}