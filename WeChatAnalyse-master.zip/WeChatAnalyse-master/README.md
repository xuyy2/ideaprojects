# WeChatAnalyse
微信爬虫，爬取朋友信息

数据展示
----

<image src="123.png" width=500>

<image src="456.png" width=500>
  
备注
--
* 这是一个微信爬虫，微信返回的是json
* 用的是百度echart.js画图
* [类似项目](https://github.com/wangqifan/ZhiHu)
* [博客](http://www.cnblogs.com/zuin/)
