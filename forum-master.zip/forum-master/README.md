###### df
###### 一个简单的论坛系统
1. 该项目开发IDE为IntelliJ IDEA，通过Maven构建，后台采用Spring、SpringMVC、MyBatis，数据库采用MySQL、Redis，前台用到jQuery，图片被上传到七牛云。
2. 修改df.properties中的mysql.password，redis.password，mail.password为您个人的配置。
3. 修改com/fc/util/MyConstant.java，将七牛云的相关配置改为您的个人配置。
4. 此项目为初学者练手项目，仅为交流，有什么错误希望大家能指出，在此感谢。
