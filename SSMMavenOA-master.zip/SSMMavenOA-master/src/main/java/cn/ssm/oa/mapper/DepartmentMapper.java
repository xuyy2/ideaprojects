package cn.ssm.oa.mapper;

import cn.ssm.oa.po.Department;
import tk.mybatis.mapper.common.Mapper;

public interface DepartmentMapper extends Mapper<Department> {
}