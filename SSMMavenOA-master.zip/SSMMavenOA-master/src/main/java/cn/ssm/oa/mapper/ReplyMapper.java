package cn.ssm.oa.mapper;

import cn.ssm.oa.po.Reply;
import tk.mybatis.mapper.common.Mapper;

public interface ReplyMapper extends Mapper<Reply> {
}