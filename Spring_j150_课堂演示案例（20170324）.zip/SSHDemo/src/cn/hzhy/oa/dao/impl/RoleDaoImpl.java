package cn.hzhy.oa.dao.impl;

import java.util.List;

import cn.hzhy.oa.dao.RoleDao;
import cn.hzhy.oa.entity.Role;

public class RoleDaoImpl implements RoleDao {

	public Role getById(int roleId) {
		return null;
	}

	public List<Role> getAll() {
		return null;
	}

}
